TRANSCENDENT LIFE IN CHRIST — SUPER ADMIN CONSOLE (DESIGN)
=========================================================
Prepared 13 November 2026 · Design mockups with demo data (not a working system)
Desktop web console, 1440 x 900, in both app themes (Glory Light and Royal Night).

WHAT IT DOES
  1. App updates: add, edit, schedule and remove sermons, series, events, declarations,
     reading plans and announcements; reorder the Home screen; switch features on/off;
     set the default theme; manage app versions, forced updates and maintenance mode.
  2. Members: search and edit profiles, see account status (active, invited,
     needs help, locked).
  3. Sign-up help: a queue of people whose sign-up failed, with the reason detected
     automatically (code not received, locked, email in use, duplicate, no smartphone,
     under 13) and one-click fixes.
  4. Register a member: staff create the account for someone who can't, after an
     identity check, and send them a secure link to finish.

THE 11 SCREENS
  A01-sign-in  Admin sign-in: Password plus a 6-digit two-step code; required for every admin.
  A02-dashboard  Dashboard: Health of the app at a glance: activity, sign-ups, people needing help, giving, recent changes.
  A03-sermons  Sermons & series: Full message library with status, views and add / edit / schedule / remove actions.
  A04-message-editor  Message editor: Add or edit a message: video, audio, scriptures, notes, schedule, push, with a live phone preview.
  A05-home-and-push  Home screen & push: Reorder and toggle Home blocks; compose, target and schedule announcements.
  A06-events  Events: Event list with registration counts; capacity, deadlines, export and reminders.
  A07-members  Members: Member directory with account status (active, invited, needs help, locked) and privacy masking.
  A08-sign-up-help  Sign-up help queue: Failed sign-ups with the reason, history, an identity check and one-click fixes.
  A09-register-a-member  Register a member: Assisted registration: details, identity check, then a secure link; warns about duplicates.
  A10-roles-and-audit  Roles & audit log: Permission matrix for six roles, two-step for all, and a tamper-proof audit log.
  A11-app-settings  App settings: Feature switches, default theme and schedule, year theme, versions, forced update, maintenance.

SECURITY RULES BUILT INTO THE DESIGN (please keep these)
  - Two-step login for every admin; super admins limited to 2-3 people.
  - Staff never see or set a member's password. Assisted registration sends the member
    a link (SMS/WhatsApp/email, 48 h) or a short-lived help-desk code (24 h).
  - Identity check before verifying an account for someone (2 of 3 checks).
  - Duplicate warning before creating a new profile.
  - Role-based access: giving data only for Finance; full phone numbers only for
    Pastor/Support; every view and change written to an audit log that can't be edited.
  - Removed content kept in an archive for 30 days.

NOTE FOR THE DEVELOPER
  Rock RMS already has a full web administration (people, groups, content, events,
  giving, security roles). This console can be built either as a simpler, church-branded
  layer over Rock's API, or by configuring Rock's own admin pages. That choice belongs
  to whoever builds the app; confirm what Rock covers before building screens from scratch.

DEMO DATA
  All names (apart from the founder), numbers, dates, campuses and amounts are invented.
  "Church Admin" stands in for the real super admin.
