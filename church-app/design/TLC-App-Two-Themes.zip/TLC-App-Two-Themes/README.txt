TRANSCENDENT LIFE IN CHRIST — ONE APP, TWO THEMES
=================================================
Prepared 13 November 2026 · Demo prototype (not a working app)

The founder liked both designs, so the app offers both, and each member chooses:
  ROYAL NIGHT  — black, gold and chrome (the crown)
  GLORY LIGHT  — white, blue and glass with touches of gold ("His marvelous light", 1 Pet 2:9)
  (Theme names are suggestions drawn from the mandate's language. Rename freely.)

HOW MEMBERS SWITCH
  - Me > Appearance (screen 21b): live previews of both themes; tap to choose.
    Also: Match my phone · Royal Night after sunset · matching app icon.
  - Side menu (screen 04b): one-tap Night / Light switch.
  The choice is saved to the member's profile and follows them across devices.

WHAT'S IN THIS FOLDER
  00-two-themes-side-by-side.png   Key screens in both themes — START HERE
  00-app-sitemap.png               Full navigation, including the theme switch
  royal-night/                     Overview sheet + all 24 screens (800 x 1736)
  glory-light/                     Overview sheet + all 24 screens (800 x 1736)
  brand/                           Logos and app icons for each theme
  developer-spec/                  THEMES.md (behaviour + build notes) and theme-tokens.json (every colour)

THE 24 SCREENS (identical in both themes)
  01-splash.png  —  Splash
  02-onboarding.png  —  Onboarding
  03-sign-in.png  —  Sign in
  04-home.png  —  Home
  04b-side-menu.png  —  Side menu
  05-watch.png  —  Watch
  06-series.png  —  Series detail
  07-now-playing.png  —  Now playing
  08-live.png  —  Live service
  09-bible.png  —  Bible
  10-the-mandate.png  —  The Mandate
  11-declarations.png  —  Declarations
  12-connect.png  —  Connect
  13-group-chat.png  —  Group chat
  14-events.png  —  Events
  15-event-detail.png  —  Event registration
  16-give.png  —  Give
  17-prayer.png  —  Prayer wall
  18-next-steps.png  —  Next steps
  19-check-in.png  —  Check-in
  20-notifications.png  —  Notifications
  21-profile.png  —  Me / Profile
  21b-appearance.png  —  Appearance
  22-about.png  —  About the church

CONTENT & PLACEHOLDERS
  Drawn from "The Transcendent Mandate" (Apostle Benjamin Zulu, (c) 2017): the series and
  its six messages, every scripture shown, the Daily Declarations and the mandate's themes.
  Illustrative placeholders to replace: member names, groups, campuses (Kabulonga,
  Woodlands), venues, dates, giving amounts, currency (Kwacha), mobile money, all counts.

LAYOUT SOURCE
  Structure follows what REA recovered from the Kingdomcity app (Rock RMS mobile shell).
  The visual design is original; no Kingdomcity artwork, text or code is used.
