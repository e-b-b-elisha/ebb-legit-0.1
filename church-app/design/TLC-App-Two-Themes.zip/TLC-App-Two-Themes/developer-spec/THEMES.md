# Theme switching — Royal Night & Glory Light

The founder approved both designs, so the app ships **one layout with two themes**.
Every screen exists in both; only colours, surfaces and the logo treatment change.

| | Royal Night | Glory Light |
|---|---|---|
| Mood | Black, gold, chrome — the crown | White, blue, glass — "His marvelous light" (1 Pet 2:9) |
| Primary | Gold gradient, dark text on buttons | Blue glass gradient, white text on buttons |
| Gold | Primary colour | Small accents only |
| Surfaces | Dark translucent panels | Frosted glass (blur + white edge) |
| App icon | Crest on black | Crest on pale blue |

## Where members switch
1. **Me → Appearance** (screen 21b): two live previews, tap to choose.
2. **Side menu** (screen 04b): a one-tap Night / Light switch at the bottom.

## Options on the Appearance screen
- **Royal Night** / **Glory Light**: manual choice.
- **Match my phone**: follow the device's light/dark setting.
- **Royal Night after sunset**: automatic switch on a schedule (default 18:30–06:00).
- **App icon**: the launcher icon changes to match the theme.

## Behaviour
- Default for new installs: **Match my phone** (needs a decision from the church; Royal Night is the alternative).
- Switch instantly, no restart, no flash of the wrong theme at launch (store the choice locally and read it before the first screen draws).
- Save the choice to the member's profile so it follows them to other devices.
- Splash screen should use the active theme.

## Implementation notes (for the developer)
- **Colours**: `theme-tokens.json` lists every token for both themes. Define them once as two style sets and swap at runtime.
- **.NET MAUI** (the reference app's framework): swap the app's merged ResourceDictionary between two theme dictionaries and use `DynamicResource` for colours; `Application.Current.UserAppTheme` handles "Match my phone".
- **Rock Mobile shell**: much of the UI is styled server-side. Confirm with a Rock developer how the shell exposes light/dark styling before committing. This was **not verified** in the analysis.
- **Glass effects**: blur is cheap on modern phones but can cost frames on older Android devices; provide a solid-colour fallback.
- **App icon switching**: iOS supports alternate icons (the system shows a short notice when it changes); Android does it with activity aliases and may reshuffle the launcher. Treat it as optional.
- **Accessibility**: check text contrast in both themes. Light-theme gold text is the risky one; it's reserved for small labels for that reason.
