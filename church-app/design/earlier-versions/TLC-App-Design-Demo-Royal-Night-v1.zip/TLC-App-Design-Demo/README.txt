TRANSCENDENT LIFE IN CHRIST — MOBILE APP DESIGN DEMO
=====================================================
Prepared 13 November 2026 · Demo prototype (not a working app)

WHAT'S IN THIS FOLDER
  00-overview-all-screens.png   All 22 screens on one sheet — start here
  00-app-sitemap.png            How every screen connects (navigation map)
  screens/                      Each screen at full phone resolution (800 x 1736)
  brand/                        The logo, cropped and prepared for app use

THE 22 SCREENS
  01-splash.png  —  Splash: Launch screen with the crest and the mandate's anchor scripture.
  02-onboarding.png  —  Onboarding: 'Hope is a Person' — the mandate's opening teaching as the first impression.
  03-sign-in.png  —  Sign in: Secure sign-in — email, Google, Apple or biometrics (OpenID Connect, as the reference app uses).
  04-home.png  —  Home: Live service, quick actions and the Word for today — the Rock 'dashboard' pattern.
  05-watch.png  —  Watch: Sermon library — featured series, continue watching, browse series.
  06-series.png  —  Series detail: Every message of 'The Transcendent Mandate', taken from the mandate's own sections.
  07-now-playing.png  —  Now playing: Sermon player with casting, background audio and synced notes and scriptures.
  08-live.png  —  Live service: Live stream with church chat, live giving, prayer and salvation responses.
  09-bible.png  —  Bible: Scripture reader with highlight, notes and audio, linked back to the mandate.
  10-the-mandate.png  —  The Mandate: The founding teaching as an in-app reader — the church's DNA, always one tap away.
  11-declarations.png  —  Declarations: Daily confessions straight from the mandate's scriptures, with streaks.
  12-connect.png  —  Connect: Find and join small groups — the Rock Groups block.
  13-group-chat.png  —  Group chat: Real-time group conversation with event cards (the Stream Chat pattern).
  14-events.png  —  Events: Calendar strip, featured conference and upcoming services.
  15-event-detail.png  —  Event registration: Event page with speakers, venue and registration (Rock Events block).
  16-give.png  —  Give: Tithes, offerings and missions — one-time or recurring, card or mobile money.
  17-prayer.png  —  Prayer wall: Share requests, pray for one another, celebrate answered prayer.
  18-next-steps.png  —  Next steps: Discipleship journey from salvation to serving (Rock Connection block).
  19-check-in.png  —  Check-in: Family QR check-in for services and kids church, with secure pick-up codes.
  20-notifications.png  —  Notifications: Live alerts, group messages, answered prayers, giving receipts.
  21-profile.png  —  Me / Profile: Profile, serving role, streaks, statements and settings.
  22-about.png  —  About the church: The mandate, founder, campuses and statement of faith.

WHERE THE CONTENT CAME FROM
  From "The Transcendent Mandate" (Apostle Benjamin Zulu, © 2017):
   - Series "The Transcendent Mandate" — its six messages are the mandate's
     own sections: What Is Hope? · Hope Is a Person · Where Do We Come In? ·
     What Is the Transcendent Life? · What Does 'Transcendent' Mean? ·
     Where Is the Devil Now?
   - Every scripture shown (Col 1:27, 1 John 4:17, 1 Pet 2:9, Isa 9:6,
     1 Tim 1:1, 2 Cor 5:17, 2 Pet 1:4, Matt 28:18-20, Col 2:15, Heb 2:14,
     1 John 5:13, 1 Tim 6:12, Rom 5:5)
   - Themes: "Hope is a Person", "Year of the Supernatural", "Go and Prosper!",
     "Fight ignorance with the Word", "You can't give what you don't have",
     "God's extended hand", "We don't lose, we don't fail"
   - The Daily Declarations screen is built entirely from the mandate's confessions.

  Illustrative placeholders (replace with real details):
   - Member names (Grace Mwansa, etc.), pastor names other than the founder
   - Group names, campuses (Kabulonga, Woodlands), venues, dates and times
   - Giving amounts, currency (Kwacha) and the mobile-money payment option
   - Viewer counts, prayer counts, statistics

HOW THE LAYOUT WAS DECIDED
  The structure follows what REA recovered from the Kingdomcity app: the
  Rock RMS mobile shell — a five-tab app whose pages are "blocks" (content,
  media, groups, chat, events, giving, prayer, check-in, next steps). The
  visual design (black, gold and chrome) is original, built to match the
  church crest. No Kingdomcity artwork, text or code is used.

BRAND FILES
  logo-emblem-black-bg.png               Full crest, tightly cropped (border removed)
  logo-emblem-transparent.png            Full crest, transparent background
  logo-mark-crown-heart-transparent.png  Crown + heart-globe only, for small spaces
  app-icon-1024.png                      Store/launcher icon, 1024 x 1024
  Note: the source logo is a 1138 x 1536 JPEG, so very large prints should
  use the original artwork file if one exists.
