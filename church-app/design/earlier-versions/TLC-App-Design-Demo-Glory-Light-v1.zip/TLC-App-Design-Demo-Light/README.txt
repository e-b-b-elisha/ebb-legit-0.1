TRANSCENDENT LIFE IN CHRIST — MOBILE APP DESIGN DEMO (LIGHT EDITION)
=====================================================================
Prepared 13 November 2026 · Demo prototype (not a working app)

THEME
  White base, blue primary, small touches of glassy gold.
  - Glass: frosted panels, buttons, tab bar and side menu (translucent white,
    blur, bright top edge, soft blue shadow).
  - Blue: primary buttons, active tab, selected chips, progress, links.
  - Gold (accent only): the crown button in the tab bar, section labels,
    badges, card hairlines, the unread counter and the Bible highlighter.
  New in this edition: a glass SIDE MENU (04b) opened from the menu button on Home.

WHAT'S IN THIS FOLDER
  00-overview-all-screens.png   All 23 screens on one sheet — start here
  00-app-sitemap.png            How every screen connects
  screens/                      Each screen at full phone resolution (800 x 1736)
  brand/                        Logo files for the light theme

THE 23 SCREENS
  01-splash.png  —  Splash: Launch screen with the crest and the mandate's anchor scripture.
  02-onboarding.png  —  Onboarding: 'Hope is a Person' — the mandate's opening teaching as the first impression.
  03-sign-in.png  —  Sign in: Secure sign-in — email, Google, Apple or biometrics (OpenID Connect, as the reference app uses).
  04-home.png  —  Home: Live service, quick actions and the Word for today — the Rock 'dashboard' pattern.
  04b-side-menu.png  —  Side menu: Glass navigation drawer — every section one tap away, with live and unread badges.
  05-watch.png  —  Watch: Sermon library — featured series, continue watching, browse series.
  06-series.png  —  Series detail: Every message of 'The Transcendent Mandate', taken from the mandate's own sections.
  07-now-playing.png  —  Now playing: Sermon player with casting, background audio and synced notes and scriptures.
  08-live.png  —  Live service: Live stream with church chat, live giving, prayer and salvation responses.
  09-bible.png  —  Bible: Scripture reader with highlight, notes and audio, linked back to the mandate.
  10-the-mandate.png  —  The Mandate: The founding teaching as an in-app reader — the church's DNA, always one tap away.
  11-declarations.png  —  Declarations: Daily confessions straight from the mandate's scriptures, with streaks.
  12-connect.png  —  Connect: Find and join small groups — the Rock Groups block.
  13-group-chat.png  —  Group chat: Real-time group conversation with event cards (the Stream Chat pattern).
  14-events.png  —  Events: Calendar strip, featured conference and upcoming services.
  15-event-detail.png  —  Event registration: Event page with speakers, venue and registration (Rock Events block).
  16-give.png  —  Give: Tithes, offerings and missions — one-time or recurring, card or mobile money.
  17-prayer.png  —  Prayer wall: Share requests, pray for one another, celebrate answered prayer.
  18-next-steps.png  —  Next steps: Discipleship journey from salvation to serving (Rock Connection block).
  19-check-in.png  —  Check-in: Family QR check-in for services and kids church, with secure pick-up codes.
  20-notifications.png  —  Notifications: Live alerts, group messages, answered prayers, giving receipts.
  21-profile.png  —  Me / Profile: Profile, serving role, streaks, statements and settings.
  22-about.png  —  About the church: The mandate, founder, campuses and statement of faith.

WHERE THE CONTENT CAME FROM
  From "The Transcendent Mandate" (Apostle Benjamin Zulu, © 2017): the series
  and its six messages (the mandate's own section headings), every scripture
  shown, the Daily Declarations, and the themes "Hope is a Person",
  "Year of the Supernatural" and "Go and Prosper!".

  Illustrative placeholders (replace with real details): member and pastor
  names other than the founder, groups, campuses (Kabulonga, Woodlands),
  venues, dates, giving amounts, currency (Kwacha), mobile money, all counts.

HOW THE LAYOUT WAS DECIDED
  Structure follows what REA recovered from the Kingdomcity app (the Rock RMS
  mobile shell: a five-tab app built from content, media, group, chat, event,
  giving, prayer, check-in and next-step blocks). The visual design is
  original. No Kingdomcity artwork, text or code is used.

BRAND FILES
  logo-emblem-transparent.png            Full crest as supplied (1324 x 1188, transparent)
  logo-mark-crown-heart-transparent.png  Crown + heart-globe only, for small spaces
  app-icon-1024.png                      Light-theme store/launcher icon
